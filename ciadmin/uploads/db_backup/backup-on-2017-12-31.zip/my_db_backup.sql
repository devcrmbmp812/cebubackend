#
# TABLE STRUCTURE FOR: ci_user_groups
#

DROP TABLE IF EXISTS `ci_user_groups`;

CREATE TABLE `ci_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (1, 'member');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (2, 'customer');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (4, 'accountant');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (7, 'aww');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (8, 'wwe');


#
# TABLE STRUCTURE FOR: ci_users
#

DROP TABLE IF EXISTS `ci_users`;

CREATE TABLE `ci_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (3, 'Admin', 'admin', 'admin', 'admin@admin.com', '12345', '$2y$10$kqiwRiCcIBsS/i0FC9k3YOE.sSVgu/PKCcO.baV8T4EDru4.qMXrS', 1, 1, 1, '', '2017-09-29 10:09:44', '2017-10-17 10:10:55');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (28, 'admin', 'John', 'Smith', 'nauman_wwe@yahoo.com', '245445545', '$2y$10$5ff6s0KicsWeSNcHyzOdXunlc3y91OBDn5kBtRU0M7tSwW4nYGkbe', 2, 1, 0, '', '2017-12-25 06:12:20', '2017-12-25 06:12:19');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (16, 'demo4', 'test', 'test', 'test3@gmai.com', '12345', '$2y$10$T5TLciHgDteRi.9bBuMn1OOzP/QFm7TQFwLGBlEwvT4Xo4lbqVmDG', 2, 1, 0, '', '2017-10-12 07:10:10', '2017-12-25 06:12:33');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (17, 'demo5', 'test', 'test', 'test4@gmai.com', '12345', '$2y$10$iQW7TKdrHNnl3jDtjYBadOxTuWRBdBcZhk2lxZ2lrIX1M4uJu6pFO', 4, 1, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:17');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (18, 'demo6', 'test', 'test', 'test5@gmai.com', '12345', '$2y$10$UEkLtiOP8Lt13vwC8KXsKOOJMnWukPPP7L/NJIpFn49rQKuA6oXD6', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:24');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (19, 'demo7', 'test', 'test', 'test6@gmai.com', '12345', '$2y$10$GSVyEzAbMjdhONCVPevbGOMAjzSGpPk62pg58W8DtG4PCSdTF5Ooy', 1, 0, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:30');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (20, 'demo8', 'test', 'test', 'test7@gmai.com', '12345', '$2y$10$6415cSa21VXXyD3vsaPwyepPyaDpPMgOJkPbZMt/AtKvNx5hRxbLy', 2, 1, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:39');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (21, 'demo9', 'test', 'test', 'test8@gmai.com', '12345', '$2y$10$.4.73sLxhwRHYZoSxbFTMu/iaKHgDYJqz9Lx3js6dmlJxZMuPG8AG', 1, 0, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:47');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (22, 'demo10', 'test', 'test', 'test9@gmai.com', '12345', '$2y$10$.Rr.YeXQ/M4QJ031O3r2k.Tc2ztOvRfCsG2EjYUxY.KZ96WjwR57O', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-10-17 11:10:53');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (23, 'demo11', 'test', 'test', 'test10@gmai.com', '12345', '$2y$10$UMA/rS5Nsn/M.vd6eReHduT34DuYvyIR.w60dlRSPq8AJffxjmO3O', 2, 1, 0, '', '2017-10-12 07:10:10', '2017-12-14 11:12:12');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (24, 'demo12', 'test', 'test', 'test1@gmai.com', '12345', '$2y$10$JlHihhr5LiGtx7rwZYbLLefdmi3JACN/yDkoJKWWESwELAGFeWOWe', 4, 1, 0, '', '2017-10-12 07:10:10', '2017-10-13 10:10:22');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (25, 'rizwan', 'rizwan', 'shahid', 'rizwan@gmail.com', '12345', '$2y$10$HdgLtow.ZkitfcEj9rs.9e4yVRFl4LDoXiqonceKnyaXBslPWMh5q', 4, 1, 0, '', '2017-10-13 09:10:37', '2017-10-17 11:10:56');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (27, 'wwe', 'wwe', 'test', 'test1@gmail.com', '123456', '$2y$10$d6hK4XEEg5.igyWFye5XrO3S813HDZy3Tr5QwrCPSgr2aVQ2eOD8y', 1, 1, 0, '', '2017-10-17 10:10:50', '2017-10-17 10:10:50');


